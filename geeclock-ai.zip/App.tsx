import React, { useState, useEffect, useCallback } from 'react';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Header } from './components/Header';
import { Clock } from './components/Clock';
import { TimerList } from './components/TimerList';
import { AddTimerModal } from './components/AddTimerModal';
import { SettingsModal } from './components/SettingsModal';
import { ChatBot } from './components/ChatBot';
import { ImageEditor } from './components/ImageEditor';
import { Icon } from './components/Icon';
import { THEMES, INITIAL_SETTINGS, ALARM_SOUNDS } from './constants';
import type { Settings, Timer as TimerType } from './types';

type ActiveTab = 'clock' | 'timers' | 'imageEditor';

const App: React.FC = () => {
    const [settings, setSettings] = useLocalStorage<Settings>('geeclock-settings', INITIAL_SETTINGS);
    const [timers, setTimers] = useLocalStorage<TimerType[]>('geeclock-timers', []);
    const [activeTab, setActiveTab] = useState<ActiveTab>('clock');
    const [isAddTimerModalOpen, setAddTimerModalOpen] = useState(false);
    const [isSettingsModalOpen, setSettingsModalOpen] = useState(false);
    const [isChatOpen, setChatOpen] = useState(false);

    useEffect(() => {
        const root = document.documentElement;
        const theme = THEMES[settings.theme]?.[settings.darkMode ? 'dark' : 'light'] || THEMES.default.dark;
      
        Object.entries(theme).forEach(([key, value]) => {
            root.style.setProperty(`--color-${key}`, value);
        });
      
        if (settings.darkMode) {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
    }, [settings]);

    const handleAddTimer = useCallback(({ label, duration }: { label: string; duration: number }) => {
        const newTimer: TimerType = {
            id: Date.now(),
            label,
            duration,
            remaining: duration,
            isRunning: false,
            startTime: null,
        };
        setTimers(prev => [...prev, newTimer]);
    }, [setTimers]);

    const handleDeleteTimer = useCallback((id: number) => {
        setTimers(prev => prev.filter(t => t.id !== id));
    }, [setTimers]);
    
    const handleToggleTimer = useCallback((id: number) => {
        setTimers(currentTimers => currentTimers.map(timer => {
            if (timer.id !== id) return timer;
            
            const isRunning = !timer.isRunning;
            if (isRunning) {
                const startTime = Date.now() - ((timer.duration - timer.remaining) * 1000);
                return { ...timer, isRunning: true, startTime };
            } else {
                if (!timer.startTime) return timer;
                const elapsed = (Date.now() - timer.startTime) / 1000;
                const remaining = timer.duration - elapsed;
                return { ...timer, isRunning: false, remaining: Math.max(0, remaining), startTime: null };
            }
        }));
    }, [setTimers]);

    const handleResetTimer = useCallback((id: number) => {
        setTimers(currentTimers => currentTimers.map(timer => {
            if (timer.id === id) {
                return { ...timer, isRunning: false, remaining: timer.duration, startTime: null };
            }
            return timer;
        }));
    }, [setTimers]);

    const alarmSoundUrl = settings.alarmSound === 'custom'
        ? settings.customAlarmSoundUrl
        : (ALARM_SOUNDS[settings.alarmSound]?.url || ALARM_SOUNDS.default.url);

    return (
        <div className="min-h-screen flex flex-col max-w-3xl mx-auto">
            {/* FIX: Replaced hasApiKey prop with aiUnlocked. */}
            <Header 
                onSettingsClick={() => setSettingsModalOpen(true)} 
                onChatClick={() => setChatOpen(true)} 
                aiUnlocked={settings.aiUnlocked} 
                showDateTime={settings.showDateTimeInHeader} 
            />
            
            <nav className="flex justify-center p-2">
                <div className="flex items-center gap-2 bg-surface p-1.5 rounded-full animate-fade-in">
                    <button onClick={() => setActiveTab('clock')} className={`px-4 py-1.5 text-sm font-semibold rounded-full flex items-center gap-2 ${activeTab === 'clock' ? 'bg-primary text-white' : 'hover:bg-background/50'}`}>
                        <Icon name="clock" className="w-5 h-5" />Clock
                    </button>
                    <button onClick={() => setActiveTab('timers')} className={`px-4 py-1.5 text-sm font-semibold rounded-full flex items-center gap-2 ${activeTab === 'timers' ? 'bg-primary text-white' : 'hover:bg-background/50'}`}>
                        <Icon name="timer" className="w-5 h-5" />Timers
                    </button>
                     {settings.aiUnlocked && (
                         <button onClick={() => setActiveTab('imageEditor')} className={`px-4 py-1.5 text-sm font-semibold rounded-full flex items-center gap-2 ${activeTab === 'imageEditor' ? 'bg-primary text-white' : 'hover:bg-background/50'}`}>
                            <Icon name="image" className="w-5 h-5" />Image Editor
                        </button>
                     )}
                </div>
            </nav>

            <main className="flex-1">
                {activeTab === 'clock' && <Clock />}
                {activeTab === 'timers' && (
                    <TimerList 
                        timers={timers} 
                        onAdd={() => setAddTimerModalOpen(true)} 
                        onDelete={handleDeleteTimer} 
                        onToggle={handleToggleTimer} 
                        onReset={handleResetTimer} 
                        alarmSoundUrl={alarmSoundUrl} 
                    />
                )}
                {/* FIX: Removed apiKey prop from ImageEditor. */}
                {activeTab === 'imageEditor' && <ImageEditor />}
            </main>
            
            {activeTab === 'timers' && (
                <div className="fixed bottom-6 right-6 z-20">
                    <button onClick={() => setAddTimerModalOpen(true)} className="p-4 bg-secondary text-white rounded-full shadow-lg hover:scale-105 transition-transform" aria-label="Add Timer">
                        <Icon name="plus" className="w-7 h-7" />
                    </button>
                </div>
            )}
            
            {/* FIX: Removed apiKey prop from AddTimerModal. */}
            <AddTimerModal 
                isOpen={isAddTimerModalOpen} 
                onClose={() => setAddTimerModalOpen(false)} 
                onAddTimer={handleAddTimer}
            />
            <SettingsModal 
                isOpen={isSettingsModalOpen} 
                onClose={() => setSettingsModalOpen(false)} 
                settings={settings} 
                onSettingsChange={setSettings} 
            />
            {/* FIX: Conditionally render ChatBot based on aiUnlocked and removed apiKey prop. */}
            {settings.aiUnlocked && (
              <ChatBot 
                  isOpen={isChatOpen} 
                  onClose={() => setChatOpen(false)} 
                  useSearch={settings.useSearch} 
                  timers={timers} 
              />
            )}
        </div>
    );
};

export default App;
